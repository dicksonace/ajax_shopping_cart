<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>

	 <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	 	<h3 class="text-white navbar-brand">Shopping Cart</h3>

	 	<div class="mr-auto"></div>
	 	<ul class="navbar-nav">
	 		<li class="nav-item text-white">
	 			<a href="index.php" class="nav-link">Item</a>
	 		</li>
	 		<li class="nav-item text-white">
	 			<a href="cart.php" class="nav-link">Cart</a>
	 		</li>
	 	</ul>
	 </nav>

</body>
</html>